  (function(){
        var localhash = (window._mNDetails && _mNDetails['locHash'] && _mNDetails['locHash']['111121628']) || '';
		var imgUrl = 'http://qsearch.media.net/flping.php?reason=32&action=4&cme=V60%2Bijqm7FJzGegrfJD%2BxypAvKduDdyFjXwMWBBMhXhj9p6coV9Jb3AXdwPOukkxvz7Y6uK06sIf17tN9poeoYU2dkxOuPdmO%2FIcr%2FGuppmu%2BlLrdeZa37cVDR%2Fdo06GHTkMzhBFYoageTXOGHAgtgEtjhV1dxiVq4%2BtmKHBMEyBvTxjuuqlPnMzFNJwCM03D1YXenQRQmhnmOufVqUCZAQ7seCvl41aBqVIB9emEDW4Y7iKsUFD2vql283ve9%2BPLFtBJnce%2FYa0479%2Fo7SRtmGsT%2F%2FY8Fn6pJID%2FGBdexgFik1kB6Ba%2BZJ%2BYHLb5OOvPQqHHuKp4WzH4YY1RaQ0cierHEWvLkTlRkTFUOGVYkYL%2BnPxpMsPIbT5iLcdhDyoYN2DtfwgCb7kSGfQH3P6yXBL4SOagLV9%2Bjo0NJt8AANKqii%2B4oTl9dmNDS02ctjQsNVMcSFpNLUHbfO8BKuSR5C0U4DZpo5NMqvk3zFqjYI7LVyJ7gVKNTl8Nfh201QPguC7RB4wHMn2%2BJEr%2F4W2exY1tLz9oTtOo%2BM54CBuxVrtT8wkvYOXSr92hlFdUOiyDfyp7uQ8FHp2NqS2lyvwSZsPLWnJhgCyjob0yegio5CvCKxQKknjRA%3D%3D%7C%7C&r='+new Date().getTime()+'&'+localhash.replace(/#/g, '&');
		if(window._mN && _mN._util && _mN._util.logNBBeacons){
			_mN._util.logNBBeacons(imgUrl);
		}else if(window._mN && _mN.util && _mN.util.logBeacons){
			_mN.util.logBeacons(imgUrl);
		}else{
			(new Image()).src = imgUrl;
		}
	})();/*Ad has been hidden*/try{window.parent.window.document.getElementById(window.frameID).style.display = "none";}catch(e){};try{var _adId = window.parent.window.document.getElementById("111121628");if(_adId){_adId.style.display = "none";}}catch(e){};try{if(parent && typeof(parent._rtClose) === "function"){  parent._rtClose("111121628"); }}catch(e){};			if(window.parent.window._mNDetails.console !== undefined && window.parent.window._mNDetails.console.mNForceConsoleCallback !== undefined){
				window.parent.window._mNDetails.console.mNForceConsoleCallback("layer2Url", 'http://cdn3ncal.media.net/fcmdynet.js?esi=1&ry=0&fvips=0&vpf=000&chost=contextual.media.net&&cid=8CU6CD37D&cpcd=VCXvISq8O5d0dB1ktjcGkA%3D%3D&crid=111121628&size=571x200&cc=FR&vif=1&requrl=http%3A%2F%2Fwww.wsj.com%2Farticles%2FSB108837661519248681&kwrf=http%3A%2F%2Fwww.google.fr&nse=3&vi=1463555927294734433&lw=1&ugd=4&bct=Leader%20(U.S.)%40%23%40&re=1&nb=1&isOffice=0', '111121628');
			}
			if(window.parent.window._mN && window.parent.window._mN.util && window.parent.window._mN.util.triggerAdTagEvent) {
			    window.parent.window._mN.util.triggerAdTagEvent('111121628', 'layerTwoFailover', false, 'FAILOVER_REASON_ENTITY_FORCED_HIDE_BLOCK');
			}
