function OAS_RICH(position) {
if (position == 'Right1') {
document.write ('<div class="ad"><div STYLE="color: #52819B; font-size: 10px; text-align: center;" >ADVERTISEMENT</div><br />\n');
document.write ('<a href="http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_10_23/caredit.a0900130/L45/1988486179/Right1/AAAS/SOL-House-PODCAST-Rt1-2006/BRAC1.html/7a397070354658396d574141416c4945?1988486179" target="_blank"><img src="http://imagec17.247realmedia.com/RealMedia/ads/Creatives/AAAS/SOL-House-PODCAST-Rt1-2006/BRAC1.png" BORDER=0 WIDTH=160 HEIGHT=150 alt="Advertisement"></a></div>\n');
}
if (position == 'Right2') {
document.write ('\n');
document.write ('\n');
document.write ('\n');
document.write ('\n');
document.write ('\n');
document.write ('\n');
document.write ('<script type="text/javascript">\n');
document.write ('//<![CDATA[\n');
document.write ('var filePath                     = "http://imagec17.247realmedia.com/RealMedia/ads/Creatives/AAAS/CAR-EPO-via-VONA-W-005828@EPO-via-VONQ-Tower-BANNER-7-Sept.swf/EPO-via-VONQ-Tower-BANNER-7-Sept.swf/1441728370";\n');
document.write ('var TFSMFlash_PRETAG             = "";\n');
document.write ('var TFSMFlash_POSTTAG            = "";\n');
document.write ('var TFSMFlash_VERSION            = "9";\n');
document.write ('var TFSMFlash_WMODE              = "opaque";\n');
document.write ('\n');
document.write ('			var TFSMFlash_OASCLICK           = "http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_10_23/caredit.a0900130/L45/917752596/Right2/AAAS/CAR-EPO-via-VONA-W-005828@EPO-via-VONQ-Tower-BANNER-7-Sept.swf/EPO-via-VONQ-Tower-BANNER-7-Sept.html/7a397070354658396d574141416c4945";\n');
document.write ('	\n');
document.write ('\n');
document.write ('\n');
document.write ('var TFSMFlash_SWFCLICKVARIABLE   = "?clickTAG="+TFSMFlash_OASCLICK + "";\n');
document.write ('var TFSMFlash_SWFFILE            = filePath + TFSMFlash_SWFCLICKVARIABLE;\n');
document.write ('var TFSMFlash_FSCOMMAND          = "";\n');
document.write ('var TFSMFlash_IMAGEALTERNATE     = "";\n');
document.write ('\n');
document.write ('\n');
document.write ('var TFSMFlash_OASALTTEXT         = "";\n');
document.write ('var TFSMFlash_OASTARGET          = "_blank";\n');
document.write ('var TFSMFlash_OASPROTOCOL        = "http://";\n');
document.write ('var TFSMFlash_OASDIM             = "width=');
document.write ("'");
document.write ('160px');
document.write ("'");
document.write (' height=');
document.write ("'");
document.write ('600px');
document.write ("'");
document.write ('";\n');
document.write ('var TFSMFlash_OASADID            = "OAS_RMF_Right2_FLASH";\n');
document.write ('document.write("<"+"scr"+"ipt type=\\');
document.write ('"text/javascript\\');
document.write ('" src=\\');
document.write ('"http://imagec17.247realmedia.com/RealMedia/ads/Creatives/AAAS/CAR-EPO-via-VONA-W-005828@EPO-via-VONQ-Tower-BANNER-7-Sept.swf/TFSMFlashWrapper301.js/1441728370\\');
document.write ('"><\\');
document.write ('/scr"+"ipt"+">");\n');
document.write ('//]]>\n');
document.write ('</script>\n');
document.write ('\n');
}
if (position == 'Top') {
document.write ('<A HREF="http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_10_23/caredit.a0900130/L45/1907745047/Top/AAAS/CAR-Cyprus-Institute-WEBOE-W-005953@605203047/Banner-Advertisement-CING-final.jpg/7a397070354658396d574141416c4945?x" target="new"><IMG SRC="http://imagec17.247realmedia.com/RealMedia/ads/Creatives/AAAS/CAR-Cyprus-Institute-WEBOE-W-005953@605203047/Banner-Advertisement-CING-final.jpg/1442504043"  WIDTH=728 HEIGHT=90 ALT="The Cyprus Institute of Neurology and Genetics"  BORDER="0"></A>');
}
if (position == 'x31') {
document.write ('<A HREF="http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_10_23/caredit.a0900130/1043612320/x31/default/empty.gif/7a397070354658396d574141416c4945?x" target="_top"><IMG SRC="http://imagec17.247realmedia.com/RealMedia/ads/Creatives/default/empty.gif/0"  WIDTH=1 HEIGHT=1 ALT="" BORDER=0 BORDER="0"></A>');
}
}
