(function($) {
	
	$(document).ready(function() {
		$('.field-name-field-hp-page-item > .field-items > .field-item').eq(3).addClass('homepage-image-temp');
	});
	
})(jQuery);