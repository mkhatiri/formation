function OAS_RICH(position) {
if (position == 'Top') {
document.write ('<A HREF="http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_12_11/caredit.a0900151/L45/1856860437/Top/AAAS/CAR-SelectBioROSLdr100201/SelectBiosciences_Banner_1_Feb_100201.gif/556e7172646b743168364d4143676e6b?x" target="new"><IMG SRC="http://imagec14.247realmedia.com/RealMedia/ads/Creatives/AAAS/CAR-SelectBioROSLdr100201/SelectBiosciences_Banner_1_Feb_100201.gif/1264622050"  WIDTH=728 HEIGHT=90 ALT="Select Biosciences"  BORDER="0"></A>');
}
if (position == 'Right1') {
document.write ('<div class="ad"><div STYLE="color: #52819B; font-size: 10px; text-align: center;">ADVERTISEMENT</div><br />\n');
document.write ('<a href="http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_12_11/caredit.a0900151/L45/1951066581/Right1/AAAS/SOL-SIG-CAR-WebROSLdrTwr-4.30.09/ACbutton.HTML.html/556e7172646b743168364d4143676e6b?1951066581" target="_blank">\n');
document.write ('<img src="http://imagec14.247realmedia.com/RealMedia/ads/Creatives/AAAS/SOL-SIG-CAR-WebROSLdrTwr-4.30.09/ACbutton.gif" alt="Advertisement"></a></div>');
}
if (position == 'Right2') {
document.write ('<p align=center><font color=#52819B size=-2>ADVERTISEMENT</font><br><SCRIPT LANGUAGE="JavaScript" type="text/javascript" SRC="http://s0b.bluestreak.com/ix.e?jss&wmode=default&s=8026264&u=&n=1431661986&cltk=http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_12_11/caredit.a0900151/L45/1431661986/Right2/AAAS/CAR-Monsanto-ROS-Twr-10.01.14/MonsantoBlueStreakTag.html/556e7172646b743168364d4143676e6b?"> </script><noscript><a href=');
document.write ("'");
document.write ('http://s0b.bluestreak.com/ix.e?hr&s=8026264&cltk=http://oascentral.sciencemag.org/RealMedia/ads/click_lx.ads/sciencecareers.sciencemag.org/career_magazine/previous_issues/articles/2009_12_11/caredit.a0900151/L45/1431661986/Right2/AAAS/CAR-Monsanto-ROS-Twr-10.01.14/MonsantoBlueStreakTag.html/556e7172646b743168364d4143676e6b?');
document.write ("'");
document.write (' target=_blank><img src=');
document.write ("'");
document.write ('http://s0b.bluestreak.com/ix.e?ir&s=8026264');
document.write ("'");
document.write (' border=0 alt=""></a></noscript>\n');
}
}
